# Node.js Templete


## Installation

Use the package manager [npm]() to install Node Modules.

```bash
npm i
```

## Usage

```javascript
//for develpoment
npm run dev

//for testing
npm start
```

